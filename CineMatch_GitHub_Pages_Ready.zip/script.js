const movies = [
  { name: "Inception", genre: "Sci-Fi", rating: 8.8 },
  { name: "Interstellar", genre: "Sci-Fi", rating: 8.7 },
  { name: "The Matrix", genre: "Sci-Fi", rating: 8.7 },
  { name: "Gravity", genre: "Sci-Fi", rating: 7.7 },
  { name: "Avengers", genre: "Action", rating: 8.0 },
  { name: "Iron Man", genre: "Action", rating: 7.9 },
  { name: "Black Panther", genre: "Action", rating: 7.3 },
  { name: "John Wick", genre: "Action", rating: 7.4 },
  { name: "Titanic", genre: "Romance", rating: 7.9 },
  { name: "The Notebook", genre: "Romance", rating: 7.8 },
  { name: "La La Land", genre: "Romance", rating: 8.0 },
  { name: "Me Before You", genre: "Romance", rating: 7.4 },
  { name: "The Conjuring", genre: "Horror", rating: 7.5 },
  { name: "Insidious", genre: "Horror", rating: 6.8 },
  { name: "It", genre: "Horror", rating: 7.3 },
  { name: "A Quiet Place", genre: "Horror", rating: 7.5 },
  { name: "Toy Story", genre: "Animation", rating: 8.3 },
  { name: "Coco", genre: "Animation", rating: 8.4 },
  { name: "Frozen", genre: "Animation", rating: 7.4 },
  { name: "Finding Nemo", genre: "Animation", rating: 8.2 }
];

const select = document.getElementById("movieSelect");
const allMovies = document.getElementById("allMovies");
const results = document.getElementById("results");
const recommendations = document.getElementById("recommendations");
const selectedMovie = document.getElementById("selectedMovie");
const resultText = document.getElementById("resultText");

movies.forEach((movie, index) => {
  const option = document.createElement("option");
  option.value = index;
  option.textContent = `${movie.name} — ${movie.genre} — ⭐ ${movie.rating}`;
  select.appendChild(option);
});

function card(movie) {
  return `
    <article class="movie-card">
      <div class="poster">${movie.name.charAt(0)}</div>
      <h4>${movie.name}</h4>
      <div class="meta">${movie.genre} · <span class="rating">★ ${movie.rating}</span></div>
    </article>
  `;
}

allMovies.innerHTML = movies.map(card).join("");

document.getElementById("recommendBtn").addEventListener("click", () => {
  const selected = movies[Number(select.value)];
  const matches = movies.filter(
    movie => movie.genre === selected.genre && movie.name !== selected.name
  );

  selectedMovie.classList.remove("hidden");
  selectedMovie.innerHTML = `<strong>${selected.name}</strong> is a ${selected.genre} movie rated ${selected.rating}.`;

  recommendations.innerHTML = matches.length
    ? matches.map(card).join("")
    : "<p>No similar movies found.</p>";

  resultText.textContent = `${matches.length} ${selected.genre} recommendation${matches.length === 1 ? "" : "s"} for ${selected.name}.`;
  results.classList.remove("hidden");
  results.scrollIntoView({ behavior: "smooth", block: "start" });
});
