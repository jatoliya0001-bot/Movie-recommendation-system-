# CineMatch — Movie Recommendation System

GitHub Pages-ready website for the college project:

- Student: Daksh Kumar
- Roll No.: 261303028
- Course: B.Tech Mechanical Engineering
- Semester: 1st Semester
- Subject: AI for Everyone
- Faculty: Vaishali Thakur
- University: SGT University
- Academic Year: 2026–2027

## Files

- `index.html` — main webpage
- `style.css` — website design and responsive layout
- `script.js` — movie data and recommendation logic

## Publish with GitHub Pages

1. Sign in to GitHub and create a **new repository**.
2. Give it a name such as `movie-recommendation-system`.
3. Set it to **Public** if you want anyone to view it.
4. Upload these three files directly into the repository root:
   - `index.html`
   - `style.css`
   - `script.js`
5. Open the repository's **Settings**.
6. Select **Pages**.
7. Under **Build and deployment**, choose:
   - Source: **Deploy from a branch**
   - Branch: **main**
   - Folder: **/ (root)**
8. Click **Save**.
9. Wait a minute or two. GitHub will display your website URL on the Pages screen.

Your website will normally look like:

`https://YOUR-USERNAME.github.io/movie-recommendation-system/`

No server or database is required. The website runs entirely in the browser.
